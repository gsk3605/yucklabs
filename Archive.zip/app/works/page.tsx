'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';

export default function Home() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoplay, setIsAutoplay] = useState(true);
  const images = Array.from({ length: 10 }, (_, i) => `/works${i + 1}.jpg`);

  // Handlers for navigating images
  const handlePrev = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? images.length - 1 : prevIndex - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex === images.length - 1 ? 0 : prevIndex + 1));
  };

  // Autoplay Effect
  useEffect(() => {
    if (!isAutoplay) return;
    const interval = setInterval(() => {
      handleNext();
    }, 5000); // Change every 5 seconds
    return () => clearInterval(interval);
  }, [isAutoplay, currentIndex]);

  // Keyboard Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'ArrowRight') handleNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="relative min-h-screen flex flex-col items-center pt-20">
      {/* Background Image with Extra Blur */}
      <div
        className="absolute inset-0 bg-cover bg-center filter blur-[15px] z-0"
        style={{
          backgroundImage: `url('/artgal.jpg')`,
        }}
      />

      {/* Dropdown Menu as Sidebar Alternative */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            className="fixed top-4 right-4 bg-gray-900 bg-opacity-10 text-white hover:blur-md z-10"
          >
            ☰
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          className="absolute top-4 right-4 w-[200px] z-20 border-black bg-transparent backdrop-blur-md text-black"
          align="end"
        >
          <DropdownMenuItem>
            <Link
              href="/exhibitions"
              className="text-4xl text-black underline hover:text-red-500 w-full block transition-colors duration-300 ease-in-out"
            >
              Exhibitions
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Link
              href="/works"
              className="text-4xl hover:text-red-400 text-pink underline w-full block transition-colors duration-300 ease-in-out"
            >
              Works
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Link
              href="/about"
              className="hover:text-red-500 text-4xl text-slate- underline w-full block transition-colors duration-300 ease-in-out"
            >
              About
            </Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Image Display */}
      <div className="mt-20 z-10 flex items-center justify-center w-full max-w-screen-lg">
        {/* Left Arrow */}
        <button
          onClick={handlePrev}
          className="absolute left-4 sm:left-10 p-2 bg-gray-800 bg-opacity-50 rounded-full hover:bg-opacity-75 text-white z-20"
        >
          &#8592; {/* Unicode Left Arrow */}
        </button>

        {/* Image with Lightbox */}
        <Dialog>
          <DialogTrigger asChild>
            <div className="relative w-full max-w-md h-[400px] cursor-pointer">
              <Image
                src={images[currentIndex]}
                alt={`Artwork ${currentIndex + 1}`}
                layout="fill"
                objectFit="contain"
                className="rounded-lg"
              />
            </div>
          </DialogTrigger>
          <DialogContent>
            <div className="relative w-full h-[500px]">
              <Image
                src={images[currentIndex]}
                alt={`Artwork ${currentIndex + 1}`}
                layout="fill"
                objectFit="contain"
                className="rounded-lg"
              />
            </div>
          </DialogContent>
        </Dialog>

        {/* Right Arrow */}
        <button
          onClick={handleNext}
          className="absolute right-4 sm:right-10 p-2 bg-gray-800 bg-opacity-50 rounded-full hover:bg-opacity-75 text-white z-20"
        >
          &#8594; {/* Unicode Right Arrow */}
        </button>
      </div>

      {/* Image Title */}
      <div className="mt-4 text-center text-lg font-medium text-white">
        Artwork {currentIndex + 1}
      </div>

      {/* Autoplay Toggle */}
      <div className="mt-4">
        <Button onClick={() => setIsAutoplay((prev) => !prev)}>
          {isAutoplay ? 'Pause Autoplay' : 'Resume Autoplay'}
        </Button>
      </div>
    </div>
  );
}
