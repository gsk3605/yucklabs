'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';

export default function Home() {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center pt-20">
      {/* Background Image with Extra Blur */}
      <div
        className="absolute inset-0 bg-cover bg-center filter blur-[15px] z-0"
        style={{
          backgroundImage: `url('/artgal.jpg')`,
        }}
      />

      {/* Dropdown Menu as Sidebar Alternative */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            className="fixed top-4 right-4 bg-gray-900 bg-opacity-10 text-white hover:blur-md z-10"
          >
            ☰
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          className="absolute top-4 right-4 w-[200px] z-20 border-black bg-transparent backdrop-blur-md text-black"
          align="end"
        >
          <DropdownMenuItem>
            <Link
              href="/exhibitions"
              className="text-4xl text-black underline hover:text-red-500 w-full block transition-colors duration-300 ease-in-out"
            >
              Exhibitions
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Link
              href="/works"
              className="text-4xl hover:text-red-400 text-pink underline w-full block transition-colors duration-300 ease-in-out"
            >
              Works
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Link
              href="/about"
              className="hover:text-red-500 text-4xl text-slate- underline w-full block transition-colors duration-300 ease-in-out"
            >
              About
            </Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Main Content */}
      <div className="relative flex flex-col items-center w-full max-w-[1200px] px-4 z-0 gap-1 mt-16">
        {/* Caleb Foerg Card */}
        <Card className="flex items-center justify-center bg-aqua w-1/2 max-w-[80%] text-center border-black shadow-lg rounded-lg mt-10 p-6">
          <CardHeader>
            <CardTitle className="text-black text-4xl font-extrabold uppercase text-center">
              <span className="block">KENNY</span>
              <span className="block">RIVERO</span>
            </CardTitle>
          </CardHeader>
        </Card>

        {/* Works Card */}
        <Link
  href="/works"
  className="relative flex items-center justify-center w-1/2 max-w-[80%] text-center border border-black shadow-lg rounded-lg mt-10 p-6 transition duration-300 group ease-in-out"
>
  {/* Background with Hover Blur */}
  <span className="absolute bg-aqua inset-0 bg-aqua rounded-lg transition duration-300 ease-in-out hover:blur-sm"></span>
  
  {/* Foreground Text */}
  <CardHeader className="relative z-10">
    <span className="text-black text-4xl font-bold transition-colors duration-300 ease-in-out group-hover:text-red-500 text-center">Works</span>
  </CardHeader>
</Link>

      </div>
    </div>
  );
}
