'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from '@/components/ui/dropdown-menu';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';

export default function Home() {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center pt-20">
      {/* Background Image with Extra Blur */}
      <div
        className="absolute inset-0 bg-cover bg-center filter blur-[15px] z-0"
        style={{
          backgroundImage: `url('/artgal.jpg')`,
        }}
      />

      {/* Dropdown Menu as Sidebar Alternative */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            className="fixed top-4 right-4 bg-gray-900 bg-opacity-10 text-white hover:blur-md z-10"
          >
            ☰
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          className="absolute top-4 right-4 w-[200px] z-20 border border-black bg-transparent backdrop-blur-md text-black"
          align="end"
        >
          <DropdownMenuItem>
            <Link
              href="/"
              className="text-4xl text-black underline hover:text-red-500 w-full block transition-colors duration-300 ease-in-out"
            >
              Home
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Link
              href="/works"
              className="text-4xl hover:text-red-400 text-pink underline w-full block transition-colors duration-300 ease-in-out"
            >
              Works
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Link
              href="/exhibitions"
              className="hover:text-red-500 text-4xl text-slate- underline w-full block transition-colors duration-300 ease-in-out"
            >
              About
            </Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      
      {/* Bio Section */}
      <div className="relative flex flex-col items-center w-[80vw] h-1/4 m-6 max-w-[1200px]">
        <Card>
          <CardHeader>
            <CardTitle className="text-black text-sm font-extrabold uppercase text-center">
              <p>
                Even when I was a kid, I would put my toys away one at a time. In
                this way, I ensured their care, safety, attention, love, and place.
                I didn’t want any of my toys to feel neglected and would feel actual
                guilt if there were any toys that I didn’t include in something.
              </p>
              <p>
                I’m only realizing this now, but I approach my drawings with the
                same sensibility and care. Any drawing I’ve made, or will make, is
                part of the same collection. All my drawings know each other and
                are only as powerful as the family of drawings (not series) they
                exist within. They live in piles in my studio and are dependent on
                one another but are also very autonomous.
              </p>
            </CardTitle>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
}
